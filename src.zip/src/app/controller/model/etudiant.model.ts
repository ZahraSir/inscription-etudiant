export class Etudiant {
}
