import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-etudiant-create',
  templateUrl: './etudiant-create.component.html',
  styleUrls: ['./etudiant-create.component.css']
})
export class EtudiantCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
