export class Inscription {
  public cne: string;
  public  nom: string;
  public  prenom: string;
  public dateNaissance: number;
  public lieuNaissance: string;
  public sexe: boolean;
  public nationalite: string;
  public telephone: string;
  public mail: string;
  public serieBac: string;
  public filiere: string;

}

